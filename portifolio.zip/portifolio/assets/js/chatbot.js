// Chatbot Elements
const chatbotToggle = document.getElementById('chatbot-toggle');
const chatbotContainer = document.getElementById('chatbot-container');
const chatbotClose = document.getElementById('chatbot-close');
const chatbotMessages = document.getElementById('chatbot-messages');
const chatbotInput = document.getElementById('chatbot-input-field');
const chatbotSend = document.getElementById('chatbot-send');

// Bot knowledge base
const botResponses = {
    services: "I offer web development, AI automation, and digital marketing services. Would you like to know more about any specific service?",
    experience: "I have over 3 years of experience in web development and AI automation, having completed 15+ successful projects.",
    contact: "You can reach me at +250 787 878 745 or email me at kamanzijeanmarievianney15@gmail.com",
    location: "I'm based in Kicukiro, Kigali, Rwanda.",
    skills: "My key skills include React.js, Node.js, Python, TensorFlow, and various AI tools like ChatGPT and DeepSeek.",
    pricing: "My pricing varies based on project requirements. Would you like to discuss your specific needs?",
    availability: "I'm currently available for new projects. Let's discuss your timeline!",
    default: "I'd be happy to help you with web development, AI automation, or digital marketing services. What would you like to know more about?"
};

// Message templates
const messageTemplates = {
    greeting: "Hello! I'm Kamanzi's AI assistant. How can I help you today?",
    farewell: "Thank you for chatting! Feel free to reach out if you need anything else.",
    thinking: "Let me think about that...",
    clarification: "Could you please provide more details about what you're looking for?"
};

// Add a message to the chat
function addMessage(message, isBot = false) {
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${isBot ? 'bot' : 'user'}`;
    
    if (isBot) {
        const iconDiv = document.createElement('div');
        iconDiv.className = 'bot-icon';
        iconDiv.innerHTML = '<i class="fas fa-robot"></i>';
        messageDiv.appendChild(iconDiv);
    }
    
    const textDiv = document.createElement('div');
    textDiv.className = 'message-text';
    textDiv.textContent = message;
    messageDiv.appendChild(textDiv);
    
    // Add typing animation for bot messages
    if (isBot) {
        messageDiv.classList.add('typing');
        setTimeout(() => {
            messageDiv.classList.remove('typing');
        }, 500);
    }
    
    chatbotMessages.appendChild(messageDiv);
    chatbotMessages.scrollTop = chatbotMessages.scrollHeight;
}

// Get bot response based on user input
function getBotResponse(message) {
    message = message.toLowerCase();
    
    // Check for greetings
    if (message.match(/^(hi|hello|hey|greetings)/)) {
        return messageTemplates.greeting;
    }
    
    // Check for farewells
    if (message.match(/^(bye|goodbye|see you|farewell)/)) {
        return messageTemplates.farewell;
    }
    
    // Check for specific topics
    if (message.includes('service') || message.includes('offer')) {
        return botResponses.services;
    } else if (message.includes('experience') || message.includes('projects')) {
        return botResponses.experience;
    } else if (message.includes('contact') || message.includes('reach') || message.includes('email')) {
        return botResponses.contact;
    } else if (message.includes('location') || message.includes('based')) {
        return botResponses.location;
    } else if (message.includes('skill') || message.includes('know')) {
        return botResponses.skills;
    } else if (message.includes('price') || message.includes('cost') || message.includes('rate')) {
        return botResponses.pricing;
    } else if (message.includes('available') || message.includes('when') || message.includes('start')) {
        return botResponses.availability;
    }
    
    // If no specific match is found
    return botResponses.default;
}

// Event Listeners
chatbotToggle.addEventListener('click', () => {
    chatbotContainer.classList.add('active');
    // Add initial greeting if it's the first time opening
    if (chatbotMessages.children.length === 0) {
        addMessage(messageTemplates.greeting, true);
    }
});

chatbotClose.addEventListener('click', () => {
    chatbotContainer.classList.remove('active');
});

function handleUserMessage() {
    const message = chatbotInput.value.trim();
    if (message) {
        // Add user message
        addMessage(message, false);
        chatbotInput.value = '';
        
        // Show typing indicator
        setTimeout(() => {
            // Get and add bot response
            const response = getBotResponse(message);
            addMessage(response, true);
        }, 500);
    }
}

chatbotSend.addEventListener('click', handleUserMessage);

chatbotInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
        handleUserMessage();
    }
});

// Add smooth transition when messages are added
const observer = new MutationObserver((mutations) => {
    mutations.forEach((mutation) => {
        if (mutation.addedNodes.length) {
            mutation.addedNodes.forEach((node) => {
                if (node.classList && node.classList.contains('message')) {
                    requestAnimationFrame(() => {
                        node.classList.add('show');
                    });
                }
            });
        }
    });
});

observer.observe(chatbotMessages, { childList: true }); 