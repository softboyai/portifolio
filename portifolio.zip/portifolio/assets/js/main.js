// Theme Toggle Functionality
const themeToggle = document.querySelector('.theme-toggle');
const themeIcon = themeToggle.querySelector('i');

// Check for saved theme preference, otherwise use system preference
const getPreferredTheme = () => {
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme) {
        return savedTheme;
    }
    return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
};

// Apply theme
const setTheme = (theme) => {
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('theme', theme);
    
    // Update icon
    if (theme === 'dark') {
        themeIcon.className = 'fas fa-sun';
    } else {
        themeIcon.className = 'fas fa-moon';
    }
};

// Initialize theme
setTheme(getPreferredTheme());

// Handle theme toggle click
themeToggle.addEventListener('click', () => {
    const currentTheme = document.documentElement.getAttribute('data-theme');
    const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
    
    // Add rotation animation
    themeIcon.style.transform = 'rotate(360deg)';
    setTimeout(() => {
        themeIcon.style.transform = '';
    }, 300);
    
    setTheme(newTheme);
});

// Listen for system theme changes
window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', (e) => {
    if (!localStorage.getItem('theme')) {
        setTheme(e.matches ? 'dark' : 'light');
    }
});

// Lazy Loading Images
document.addEventListener('DOMContentLoaded', function() {
    // Implement Intersection Observer for lazy loading
    if ('IntersectionObserver' in window) {
        const lazyImages = document.querySelectorAll('.lazy-load');
        
        const imageObserver = new IntersectionObserver(function(entries, observer) {
            entries.forEach(function(entry) {
                if (entry.isIntersecting) {
                    const img = entry.target;
                    img.classList.add('loaded');
                    imageObserver.unobserve(img);
                }
            });
        }, {
            rootMargin: '0px 0px 200px 0px'
        });
        
        lazyImages.forEach(function(image) {
            imageObserver.observe(image);
        });
    } else {
        // Fallback for browsers that don't support Intersection Observer
        let lazyImages = document.querySelectorAll('.lazy-load');
        
        function lazyLoad() {
            lazyImages.forEach(function(img) {
                if ((img.getBoundingClientRect().top <= window.innerHeight && 
                     img.getBoundingClientRect().bottom >= 0) && 
                    getComputedStyle(img).display !== 'none') {
                    img.classList.add('loaded');
                    
                    // Remove from the array once loaded
                    lazyImages = Array.from(lazyImages).filter(function(image) {
                        return image !== img;
                    });
                    
                    // If all images are loaded, remove the scroll event
                    if (lazyImages.length === 0) {
                        document.removeEventListener('scroll', lazyLoad);
                        window.removeEventListener('resize', lazyLoad);
                        window.removeEventListener('orientationChange', lazyLoad);
                    }
                }
            });
        }
        
        document.addEventListener('scroll', lazyLoad);
        window.addEventListener('resize', lazyLoad);
        window.addEventListener('orientationChange', lazyLoad);
    }
    
    // Preload critical resources
    const preloadLinks = [
        '/assets/images/favicon.png',
        '/assets/css/style.css'
    ];
    
    preloadLinks.forEach(link => {
        const preloadLink = document.createElement('link');
        preloadLink.href = link;
        preloadLink.rel = 'preload';
        preloadLink.as = link.includes('.css') ? 'style' : 'image';
        document.head.appendChild(preloadLink);
    });
});

// Smooth Scrolling for Navigation Links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        
        const targetId = this.getAttribute('href');
        if (targetId === '#') return;
        
        const targetElement = document.querySelector(targetId);
        if (targetElement) {
            // Close mobile menu if open
            const navLinks = document.querySelector('.nav-links');
            if (navLinks.classList.contains('active')) {
                navLinks.classList.remove('active');
            }
            
            // Smooth scroll to element
            targetElement.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// Performance optimization for animations
// Use requestAnimationFrame for smoother animations
function debounce(func, wait = 20, immediate = true) {
    let timeout;
    return function() {
        const context = this, args = arguments;
        const later = function() {
            timeout = null;
            if (!immediate) func.apply(context, args);
        };
        const callNow = immediate && !timeout;
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
        if (callNow) func.apply(context, args);
    };
}

// Animate elements when they come into view
const animateOnScroll = () => {
    const elements = document.querySelectorAll('.animate-fade-in');
    
    elements.forEach(element => {
        const elementTop = element.getBoundingClientRect().top;
        const elementVisible = 150;
        
        if (elementTop < window.innerHeight - elementVisible) {
            element.classList.add('active');
        }
    });
};

// Add event listener with debounce for better performance
window.addEventListener('scroll', debounce(animateOnScroll));

// Trigger initial animation check
animateOnScroll();

// Handle form submission with validation and feedback
const handleContactForm = () => {
    const contactForm = document.getElementById('contact-form');
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            // Basic form validation
            const nameInput = document.getElementById('name');
            const emailInput = document.getElementById('email');
            const messageInput = document.getElementById('message');
            
            let isValid = true;
            
            // Name validation
            if (!nameInput.value.trim()) {
                showError(nameInput, 'Please enter your name');
                isValid = false;
            } else {
                removeError(nameInput);
            }
            
            // Email validation
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailInput.value.trim() || !emailRegex.test(emailInput.value)) {
                showError(emailInput, 'Please enter a valid email address');
                isValid = false;
            } else {
                removeError(emailInput);
            }
            
            // Message validation
            if (!messageInput.value.trim()) {
                showError(messageInput, 'Please enter your message');
                isValid = false;
            } else {
                removeError(messageInput);
            }
            
            if (!isValid) {
                e.preventDefault();
            }
        });
    }
};

function showError(input, message) {
    const formGroup = input.parentElement;
    const errorElement = formGroup.querySelector('.error-message') || document.createElement('div');
    
    if (!formGroup.querySelector('.error-message')) {
        errorElement.className = 'error-message';
        formGroup.appendChild(errorElement);
    }
    
    errorElement.textContent = message;
    input.classList.add('error');
}

function removeError(input) {
    const formGroup = input.parentElement;
    const errorElement = formGroup.querySelector('.error-message');
    
    if (errorElement) {
        formGroup.removeChild(errorElement);
    }
    
    input.classList.remove('error');
}

// Call the form handler when DOM is loaded
document.addEventListener('DOMContentLoaded', handleContactForm);

// Add structured data dynamically for better SEO
function addStructuredData() {
    // Skills data for JobPosting schema
    const skills = Array.from(document.querySelectorAll('.skill-card h3')).map(skill => skill.textContent);
    
    // Projects data for CreativeWork schema
    const projects = Array.from(document.querySelectorAll('.project-card')).map(project => {
        const title = project.querySelector('h3').textContent;
        const description = project.querySelector('p').textContent;
        const image = project.querySelector('img').src;
        const codeUrl = project.querySelector('.project-links a:first-child').href;
        const demoUrl = project.querySelector('.project-links a:last-child').href;
        
        return {
            "@type": "SoftwareSourceCode",
            "name": title,
            "description": description,
            "image": image,
            "codeRepository": codeUrl,
            "url": demoUrl
        };
    });
    
    // Person schema with portfolio details
    const personSchema = {
        "@context": "https://schema.org",
        "@type": "Person",
        "name": "Kamanzi Jean Marie Vianney",
        "url": window.location.href,
        "image": document.querySelector('.profile-img img').src,
        "jobTitle": "Web Developer & AI Specialist",
        "description": document.querySelector('.hero p').textContent,
        "address": {
            "@type": "PostalAddress",
            "addressLocality": "Kigali",
            "addressRegion": "Kigali",
            "addressCountry": "Rwanda"
        },
        "knowsAbout": skills,
        "worksFor": {
            "@type": "Organization",
            "name": "Freelance Professional"
        },
        "mainEntityOfPage": {
            "@type": "WebPage",
            "@id": window.location.href
        },
        "sameAs": [
            "https://github.com/softboyai",
            "https://www.linkedin.com/in/jean-marie-vianney-kamanzi-6a732a34b"
        ]
    };
    
    // Create script element for JSON-LD
    const script = document.createElement('script');
    script.type = 'application/ld+json';
    script.textContent = JSON.stringify(personSchema);
    document.head.appendChild(script);
    
    // Create project schemas
    const projectSchema = {
        "@context": "https://schema.org",
        "@type": "ItemList",
        "itemListElement": projects.map((project, index) => ({
            "@type": "ListItem",
            "position": index + 1,
            "item": project
        }))
    };
    
    const projectScript = document.createElement('script');
    projectScript.type = 'application/ld+json';
    projectScript.textContent = JSON.stringify(projectSchema);
    document.head.appendChild(projectScript);
}

// Call the function after DOM is loaded
document.addEventListener('DOMContentLoaded', addStructuredData);

// Rwanda-specific SEO enhancements
function enhanceLocalSEO() {
    // Add hreflang for Rwanda
    const hreflangLink = document.createElement('link');
    hreflangLink.rel = 'alternate';
    hreflangLink.hreflang = 'en-rw';
    hreflangLink.href = window.location.href;
    document.head.appendChild(hreflangLink);
    
    // Add local business schema for Rwanda
    const localBusinessSchema = {
        "@context": "https://schema.org",
        "@type": "LocalBusiness",
        "name": "Kamanzi Jean Marie Vianney Web Development",
        "description": "Professional web development and AI services in Kigali, Rwanda",
        "url": window.location.href,
        "telephone": "+250787878745",
        "address": {
            "@type": "PostalAddress",
            "streetAddress": "Kigali",
            "addressLocality": "Kigali",
            "addressRegion": "Kigali",
            "addressCountry": "Rwanda"
        },
        "geo": {
            "@type": "GeoCoordinates",
            "latitude": "-1.9441",
            "longitude": "30.0619"
        },
        "priceRange": "$$",
        "openingHoursSpecification": {
            "@type": "OpeningHoursSpecification",
            "dayOfWeek": [
                "Monday",
                "Tuesday",
                "Wednesday",
                "Thursday",
                "Friday"
            ],
            "opens": "09:00",
            "closes": "18:00"
        }
    };
    
    const localBusinessScript = document.createElement('script');
    localBusinessScript.type = 'application/ld+json';
    localBusinessScript.textContent = JSON.stringify(localBusinessSchema);
    document.head.appendChild(localBusinessScript);
}

// Call the function after DOM is loaded
document.addEventListener('DOMContentLoaded', enhanceLocalSEO);

// Mobile Navigation
const hamburger = document.querySelector('.hamburger');
const navLinks = document.querySelector('.nav-links');

if (hamburger && navLinks) {
    hamburger.addEventListener('click', () => {
        const isExpanded = hamburger.getAttribute('aria-expanded') === 'true';
        hamburger.setAttribute('aria-expanded', !isExpanded);
        navLinks.classList.toggle('open');
    });

    // Close mobile menu when clicking links
    navLinks.querySelectorAll('a').forEach(link => {
        link.addEventListener('click', () => {
            navLinks.classList.remove('open');
            hamburger.setAttribute('aria-expanded', 'false');
        });
    });
}

// About Section Animation
function initializeAboutAnimation() {
    const aboutSection = document.querySelector('#about');
    const paragraphs = document.querySelectorAll('.about-text p');
    const statCards = document.querySelectorAll('.stat-card');

    if (aboutSection && paragraphs.length && statCards.length) {
        // Remove initial opacity 0
        paragraphs.forEach(p => {
            p.style.opacity = '1';
            p.style.transform = 'translateY(0)';
        });

        statCards.forEach(card => {
            card.style.opacity = '1';
            card.style.transform = 'scale(1)';
        });

        // Add animation classes
        aboutSection.classList.add('animate-fade-in');
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    // Animate paragraphs
                    paragraphs.forEach((p, index) => {
                        setTimeout(() => {
                            p.style.opacity = '1';
                            p.style.transform = 'translateY(0)';
                        }, 200 * (index + 1));
                    });

                    // Animate stat cards
                    statCards.forEach((card, index) => {
                        setTimeout(() => {
                            card.style.opacity = '1';
                            card.style.transform = 'scale(1)';
                        }, index * 200);
                    });

                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.1 });

        observer.observe(aboutSection);
    }
}

// Initialize animations when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    initializeAboutAnimation();
});

// Form Submission
const contactForm = document.getElementById('contact-form');
const formStatus = document.getElementById('form-status');

if (contactForm) {
    contactForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        formStatus.textContent = 'Sending...';

        try {
            const response = await fetch(contactForm.action, {
                method: 'POST',
                body: new FormData(contactForm),
                headers: {
                    'Accept': 'application/json'
                }
            });

            if (response.ok) {
                formStatus.textContent = 'Thank you! Your message has been sent.';
                contactForm.reset();
            } else {
                throw new Error('Network response was not ok');
            }
        } catch (error) {
            formStatus.textContent = 'Oops! There was a problem sending your message. Please try again.';
        }
    });
}

// Chatbot Functionality
const chatbotToggle = document.getElementById('chatbot-toggle');
const chatbotContainer = document.getElementById('chatbot-container');
const chatbotClose = document.getElementById('chatbot-close');
const chatbotMessages = document.getElementById('chatbot-messages');
const chatbotInput = document.getElementById('chatbot-input-field');
const chatbotSend = document.getElementById('chatbot-send');

let currentContext = 'greeting';

const botResponses = {
    greeting: {
        message: "Hello! 👋 I'm Kamanzi's AI assistant. How can I help you today?\n\n1. Learn about Kamanzi\n2. Our Services\n3. View Projects\n4. Technical Skills\n5. Contact Information",
        options: ["1", "2", "3", "4", "5"]
    },
    about: {
        message: "Kamanzi Jean Marie Vianney is a Web Developer & AI Specialist based in Kigali, Rwanda. What would you like to know?\n\n1. Professional Background\n2. Experience & Achievements\n3. View Services\n4. Back to Main Menu",
        options: ["1", "2", "3", "4"]
    },
    background: {
        message: "Professional Background:\n\n💻 Technical Expertise\n• Full-stack Web Development\n• AI & Automation Solutions\n• Digital Marketing Strategies\n\n🎓 Key Focus Areas\n• Modern Web Applications\n• Business Process Automation\n• Digital Transformation\n\n1. View Experience\n2. View Services\n3. Back to About\n4. Main Menu",
        options: ["1", "2", "3", "4"]
    },
    experience: {
        message: "Professional Experience & Achievements:\n\n🌟 Highlights\n• 3+ years in Web Development & AI\n• 15+ Successful Projects\n• 15+ Satisfied Clients\n• 100% Client Satisfaction\n\n💼 Project Types\n• E-commerce Platforms\n• Business Automation\n• Digital Marketing\n\n1. View Projects\n2. Discuss Collaboration\n3. Back to About\n4. Main Menu",
        options: ["1", "2", "3", "4"]
    },
    services: {
        message: "I specialize in the following services. Which area interests you?\n\n1. Web Development Solutions\n2. AI & Automation Services\n3. Digital Marketing & SEO\n4. Discuss Your Project\n5. Back to Main Menu",
        options: ["1", "2", "3", "4", "5"]
    },
    webdev: {
        message: "Web Development Services:\n\n🌐 Custom Website Development\n• Modern, responsive designs\n• E-commerce platforms\n• Business websites\n• Portfolio websites\n\n💻 Web Applications\n• Custom web applications\n• Admin dashboards\n• Booking systems\n• CRM systems\n\n1. View Sample Projects\n2. Discuss Your Project\n3. Back to Services\n4. Main Menu",
        options: ["1", "2", "3", "4"]
    },
    ai: {
        message: "AI & Automation Services:\n\n🤖 Business Process Automation\n• Workflow automation\n• Data processing\n• Task scheduling\n\n🧠 AI Solutions\n• Custom chatbots\n• AI recommendations\n• Data analysis\n\n1. View Sample Projects\n2. Discuss Implementation\n3. Back to Services\n4. Main Menu",
        options: ["1", "2", "3", "4"]
    },
    marketing: {
        message: "Digital Marketing & SEO Services:\n\n📈 SEO Services\n• Website optimization\n• Content strategy\n• Technical SEO\n\n📱 Social Media\n• Content creation\n• Campaign management\n• Analytics & reporting\n\n1. View Success Stories\n2. Discuss Strategy\n3. Back to Services\n4. Main Menu",
        options: ["1", "2", "3", "4"]
    },
    projects: {
        message: "Here are my featured projects. Select one to learn more:\n\n1. E-Commerce Platform\n2. Butchery Ordering System\n3. Event Booking System\n4. Imanzi Solutions Portfolio\n5. Back to Main Menu",
        options: ["1", "2", "3", "4", "5"]
    },
    ecommerce: {
        message: "🛍️ E-Commerce Platform\n\nKey Features:\n• AI-powered recommendations\n• Real-time inventory\n• Secure payments\n• Order tracking\n• Admin dashboard\n\nTechnologies:\n• React.js, Node.js\n• MongoDB\n• AI integration\n\n1. View Live Demo\n2. View Other Projects\n3. Discuss Similar Project\n4. Main Menu",
        options: ["1", "2", "3", "4"]
    },
    butchery: {
        message: "🥩 Butchery Ordering System\n\nKey Features:\n• Online ordering\n• Inventory tracking\n• Delivery management\n• SMS notifications\n\nTechnologies:\n• React.js, Node.js\n• MongoDB\n• SMS API\n\n1. View Live Demo\n2. View Other Projects\n3. Discuss Similar Project\n4. Main Menu",
        options: ["1", "2", "3", "4"]
    },
    event: {
        message: "📅 Event Booking System\n\nKey Features:\n• Calendar management\n• Automated notifications\n• Payment processing\n• Ticket generation\n\nTechnologies:\n• React.js, Node.js\n• PostgreSQL\n• Email automation\n\n1. View Live Demo\n2. View Other Projects\n3. Discuss Similar Project\n4. Main Menu",
        options: ["1", "2", "3", "4"]
    },
    imanzi: {
        message: "💼 Imanzi Solutions Portfolio\n\nKey Features:\n• Modern design\n• Service showcase\n• Blog section\n• SEO optimization\n\nTechnologies:\n• React.js\n• Tailwind CSS\n• CMS integration\n\n1. View Live Demo\n2. View Other Projects\n3. Discuss Similar Project\n4. Main Menu",
        options: ["1", "2", "3", "4"]
    },
    contact: {
        message: "Let's discuss your project! You can reach me through:\n\n📞 Phone: +250 787 878 745\n📧 Email: kamanzijeanmarievianney15@gmail.com\n📍 Location: Kicukiro, Kigali, Rwanda\n\n1. Chat on WhatsApp (Recommended)\n2. Schedule a Call\n3. Back to Main Menu",
        options: ["1", "2", "3"]
    }
};

function addMessage(message, isBot = false) {
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${isBot ? 'bot' : 'user'}`;
    
    if (isBot) {
        const icon = document.createElement('i');
        icon.className = 'fas fa-robot';
        messageDiv.appendChild(icon);
    }
    
    const messageP = document.createElement('p');
    messageP.innerHTML = message.replace(/\n/g, '<br>');
    messageDiv.appendChild(messageP);
    
    chatbotMessages.appendChild(messageDiv);
    chatbotMessages.scrollTop = chatbotMessages.scrollHeight;
}

function handleWhatsApp() {
    window.open('https://wa.me/250787878745', '_blank');
    return "I've opened WhatsApp for you. Looking forward to discussing your project! 😊\n\nType 'menu' to return to the main menu.";
}

function getBotResponse(message) {
    const input = message.toLowerCase();
    
    // Handle menu navigation
    if (input.includes('menu') || input === '4' || input === '5') {
        currentContext = 'greeting';
        return botResponses.greeting.message;
    }

    // Handle WhatsApp redirects
    if (input.includes('whatsapp') || input.includes('discuss') || 
        (currentContext === 'contact' && input === '1')) {
        return handleWhatsApp();
    }

    // Context-based responses
    switch (currentContext) {
        case 'greeting':
            if (input === '1' || input.includes('about')) {
                currentContext = 'about';
                return botResponses.about.message;
            } else if (input === '2' || input.includes('service')) {
                currentContext = 'services';
                return botResponses.services.message;
            } else if (input === '3' || input.includes('project')) {
                currentContext = 'projects';
                return botResponses.projects.message;
            } else if (input === '4' || input.includes('skill')) {
                return "My key skills include:\n\n💻 Web Development\n• React.js, Node.js\n• HTML5, CSS3, JavaScript\n\n🤖 AI & Automation\n• Python, TensorFlow\n• ChatGPT, DeepSeek\n\n📱 Digital Marketing\n• SEO & Analytics\n• Social Media Management\n\nType 'menu' to return to main menu";
            } else if (input === '5' || input.includes('contact')) {
                currentContext = 'contact';
                return botResponses.contact.message;
            }
            break;

        case 'about':
            if (input === '1' || input.includes('background')) {
                currentContext = 'background';
                return botResponses.background.message;
            } else if (input === '2' || input.includes('experience')) {
                currentContext = 'experience';
                return botResponses.experience.message;
            } else if (input === '3' || input.includes('service')) {
                currentContext = 'services';
                return botResponses.services.message;
            }
            break;

        case 'services':
            if (input === '1' || input.includes('web')) {
                currentContext = 'webdev';
                return botResponses.webdev.message;
            } else if (input === '2' || input.includes('ai')) {
                currentContext = 'ai';
                return botResponses.ai.message;
            } else if (input === '3' || input.includes('market')) {
                currentContext = 'marketing';
                return botResponses.marketing.message;
            }
            break;

        case 'projects':
            if (input === '1' || input.includes('ecommerce')) {
                currentContext = 'ecommerce';
                return botResponses.ecommerce.message;
            } else if (input === '2' || input.includes('butchery')) {
                currentContext = 'butchery';
                return botResponses.butchery.message;
            } else if (input === '3' || input.includes('event')) {
                currentContext = 'event';
                return botResponses.event.message;
            } else if (input === '4' || input.includes('imanzi')) {
                currentContext = 'imanzi';
                return botResponses.imanzi.message;
            }
            break;

        case 'contact':
            if (input === '2' || input.includes('call')) {
                window.location.href = 'tel:+250787878745';
                return "Initiating call... If it doesn't start automatically, please call +250 787 878 745\n\nType 'menu' to return to main menu";
            }
            break;
    }

    // Handle project demos
    if (input.includes('demo')) {
        const demoUrls = {
            ecommerce: 'https://ecommerce-demo.netlify.app',
            butchery: 'https://butchery-system.netlify.app',
            event: 'https://event-booking.netlify.app',
            imanzi: 'https://imanziaisolutionsrw.netlify.app'
        };
        const url = demoUrls[currentContext];
        if (url) {
            window.open(url, '_blank');
            return "Opening live demo in a new tab...\n\n1. Discuss Similar Project\n2. Back to Projects\n3. Main Menu";
        }
    }

    // Handle pricing inquiries
    if (input.includes('price') || input.includes('cost') || input.includes('budget')) {
        return "I provide customized solutions based on your specific needs. Let's discuss your project requirements on WhatsApp.\n\n1. Chat on WhatsApp\n2. Back to Main Menu";
    }

    // Default response
    return "I'm not sure I understand. Please choose from the available options or type 'menu' to see the main menu.";
}

// Chatbot Event Listeners
if (chatbotToggle && chatbotContainer && chatbotClose && chatbotInput && chatbotSend) {
    chatbotToggle.addEventListener('click', () => {
        chatbotContainer.classList.toggle('active');
        chatbotToggle.setAttribute('aria-expanded', 
            chatbotContainer.classList.contains('active'));
    });

    chatbotClose.addEventListener('click', () => {
        chatbotContainer.classList.remove('active');
        chatbotToggle.setAttribute('aria-expanded', 'false');
    });

    chatbotSend.addEventListener('click', () => {
        const message = chatbotInput.value.trim();
        if (message) {
            addMessage(message, false);
            chatbotInput.value = '';
            setTimeout(() => {
                addMessage(getBotResponse(message), true);
            }, 500);
        }
    });

    chatbotInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            chatbotSend.click();
        }
    });
}

// Scroll Animation for Cards
const cardObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = '1';
            entry.target.style.transform = 'translateY(0)';
        }
    });
}, { threshold: 0.1 });

document.querySelectorAll('.skill-card, .project-card').forEach((el) => {
    el.style.opacity = '0';
    el.style.transform = 'translateY(20px)';
    el.style.transition = 'all 0.6s ease';
    cardObserver.observe(el);
});

// Live Code Animation
const codeContainer = document.querySelector('.code-content');
const typingCode = document.querySelector('.typing-code');

if (typingCode) {
    const codeLines = typingCode.textContent.trim().split('\n');
    typingCode.textContent = ''; // Clear original content

    // Function to add syntax highlighting
    function highlightSyntax(text) {
        return text
            .replace(/\b(class|constructor|async|const|return|this|function|let|var|if|else|for|while)\b/g, '<span class="code-keyword">$1</span>')
            .replace(/(['"`])(.*?)\1/g, '<span class="code-string">$1$2$1</span>')
            .replace(/\b(buildProject|automateTasks|createSolution|implementAI)\b/g, '<span class="code-function">$1</span>')
            .replace(/\b(name|skills|passion|solution|efficiency|quality|innovation)\b/g, '<span class="code-variable">$1</span>')
            .replace(/\b(true|false|null|undefined)\b/g, '<span class="code-keyword">$1</span>')
            .replace(/(\{|\}|\[|\]|\(|\)|=|>|\.)/g, '<span class="code-operator">$1</span>')
            .replace(/\/\/(.*)/g, '<span class="code-comment">$1</span>');
    }

    // Enhanced typing animation
    async function typeCode() {
        let delay = 50; // Base delay for typing
        
        for (let i = 0; i < codeLines.length; i++) {
            const line = codeLines[i];
            const lineElement = document.createElement('div');
            lineElement.className = 'code-line';
            typingCode.appendChild(lineElement);

            // Add syntax highlighting and animate each character
            const highlightedLine = highlightSyntax(line);
            const tempDiv = document.createElement('div');
            tempDiv.innerHTML = highlightedLine;
            
            let currentText = '';
            const textContent = tempDiv.textContent;
            
            for (let j = 0; j < textContent.length; j++) {
                currentText += textContent[j];
                lineElement.innerHTML = highlightSyntax(currentText);
                await new Promise(resolve => setTimeout(resolve, delay));
            }
            
            // Final line with proper syntax highlighting
            lineElement.innerHTML = highlightedLine;
            
            // Add pause between lines
            await new Promise(resolve => setTimeout(resolve, 100));
        }
    }

    // Start animation when in view
    const codeObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting && !typingCode.dataset.animated) {
                typingCode.dataset.animated = 'true';
                typeCode();
                codeObserver.unobserve(entry.target);
            }
        });
    }, { threshold: 0.3 });

    codeObserver.observe(typingCode);
}

// Enhanced section animations with stagger effect
const sections = document.querySelectorAll('section');
sections.forEach((section, index) => {
    section.style.opacity = '0';
    section.style.transform = 'translateY(30px)';
    
    const sectionObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                // Add stagger delay based on section index
                setTimeout(() => {
                    entry.target.style.transition = 'all 0.8s cubic-bezier(0.4, 0, 0.2, 1)';
                    entry.target.style.opacity = '1';
                    entry.target.style.transform = 'translateY(0)';
                }, index * 100);
                
                sectionObserver.unobserve(entry.target);
            }
        });
    }, { threshold: 0.2 });

    sectionObserver.observe(section);
});

// Update existing theme toggle functionality with enhanced animation
if (typeof themeToggle !== 'undefined' && themeToggle) {
    // Add rotation animation to existing click handler
    themeToggle.addEventListener('click', () => {
        themeToggle.style.transform = 'rotate(360deg)';
        setTimeout(() => {
            themeToggle.style.transform = 'none';
        }, 300);
    });
}

// Section Animation
const sectionObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('visible');
        }
    });
}, { threshold: 0.2 });

document.querySelectorAll('section').forEach(section => {
    sectionObserver.observe(section);
});

// 3D Card Effect
document.querySelectorAll('.project-card, .skill-card').forEach(card => {
    card.addEventListener('mousemove', (e) => {
        const rect = card.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        
        const centerX = rect.width / 2;
        const centerY = rect.height / 2;
        
        const rotateX = (y - centerY) / 10;
        const rotateY = (centerX - x) / 10;
        
        card.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) translateZ(50px)`;
    });
    
    card.addEventListener('mouseleave', () => {
        card.style.transform = 'perspective(1000px) rotateX(0) rotateY(0) translateZ(0)';
    });
});

// Enhanced Project Links
document.querySelectorAll('.project-links a').forEach(link => {
    link.addEventListener('mouseenter', (e) => {
        const rect = link.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        
        link.style.setProperty('--x', `${x}px`);
        link.style.setProperty('--y', `${y}px`);
    });
});

// Stat Cards Pop Animation
function animateStatCards() {
    const cards = document.querySelectorAll('.stat-card');
    cards.forEach((card, index) => {
        setTimeout(() => {
            card.style.opacity = '1';
            card.style.transform = 'translateY(0)';
        }, index * 200);
    });
}

// Initialize animations
document.addEventListener('DOMContentLoaded', () => {
    animateStatCards();
});

// Handle WhatsApp Toggle Functionality
function initWhatsAppToggle() {
    const whatsappToggleBtn = document.getElementById('whatsapp-toggle-btn');
    const whatsappOptions = document.getElementById('whatsapp-options');
    
    if (whatsappToggleBtn && whatsappOptions) {
        whatsappToggleBtn.addEventListener('click', () => {
            whatsappOptions.classList.toggle('active');
            
            // Add a small bounce animation to the button
            whatsappToggleBtn.style.transform = 'scale(0.8)';
            setTimeout(() => {
                whatsappToggleBtn.style.transform = '';
            }, 200);
            
            // Close options when clicking outside
            if (whatsappOptions.classList.contains('active')) {
                const closeOnClickOutside = (e) => {
                    if (!whatsappToggleBtn.contains(e.target) && !whatsappOptions.contains(e.target)) {
                        whatsappOptions.classList.remove('active');
                        document.removeEventListener('click', closeOnClickOutside);
                    }
                };
                
                // Use setTimeout to prevent immediate closing when the button is clicked
                setTimeout(() => {
                    document.addEventListener('click', closeOnClickOutside);
                }, 100);
            }
        });
        
        // Track WhatsApp clicks for analytics
        const whatsappLinks = document.querySelectorAll('.whatsapp-option');
        whatsappLinks.forEach(link => {
            link.addEventListener('click', (e) => {
                // If you have analytics, you can track clicks here
                const serviceType = link.querySelector('span').textContent;
                console.log(`WhatsApp interaction: ${serviceType}`);
                
                // Add a slight delay for animation before opening WhatsApp
                e.preventDefault();
                setTimeout(() => {
                    window.open(link.href, '_blank');
                }, 300);
            });
        });
    }
}

// Initialize WhatsApp toggle when DOM is loaded
document.addEventListener('DOMContentLoaded', initWhatsAppToggle);